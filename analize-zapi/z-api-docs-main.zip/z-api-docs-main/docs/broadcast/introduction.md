---
id: introduction
title: Introdução
---

:::warning Limitação do WhatsApp Web
Devido a esse recurso **não estar disponível no WhatsApp Web**, a **Z-API atualmente não oferece suporte ao envio de mensagens via listas de transmissão**. Essa é uma limitação da própria plataforma do WhatsApp Web.
:::

## Lista de transmissão

Como já mencionado anteriormente, para o WhatsApp tudo é tratado como um chat, e com as listas de transmissão não é diferente. Assim como nos grupos, é possível identificar suas listas de transmissão através do método **get /chats**.

As listas de transmissão possuem um identificador (ID/Fone) com o sufixo -broadcast, como por exemplo: **1624901640-broadcast**.

Além disso, diferente dos grupos, as interações originadas de listas de transmissão ocorrem de forma individual. Ou seja, quando um destinatário responde a uma mensagem enviada por lista de transmissão, essa resposta será recebida como uma conversa individual, permitindo interação direta com o contato.

